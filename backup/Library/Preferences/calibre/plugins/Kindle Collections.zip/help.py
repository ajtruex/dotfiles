# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

from __future__ import absolute_import

__license__   = 'GPL v3'
__copyright__ = '2011-2018, meme'
__docformat__ = 'restructuredtext en'

#####################################################################
# Help
#####################################################################

HELP_URL = 'http://www.mobileread.com/forums/showthread.php?t=244202'

try:
    from PyQt5.Qt import QUrl
except:
    from PyQt4.Qt import QUrl
from calibre.gui2 import open_url
from calibre_plugins.kindle_collections.utilities import debug_print

#####################################################################

# Display help information
def run():
    debug_print('BEGIN Help')
    url = HELP_URL
    open_url(QUrl(url))
    debug_print('END Help')
